extends Node

const RUTA_PUNTAJES = "user://puntajes.json"


var categorias = {
	"Países": [
		{"palabra": "COLOMBIA", "pista": "País de Sudamérica"},
		{"palabra": "ARGENTINA", "pista": "País sudamericano"},
		{"palabra": "ESPAÑA", "pista": "País europeo"}
	],
	"Tecnología": [
		{"palabra": "COMPUTADORA", "pista": "Máquina de procesamiento"},
		{"palabra": "ALGORITMO", "pista": "Secuencia lógica de pasos"}
	],
	"Animales": [
		{"palabra": "ELEFANTE", "pista": "Mamífero de gran tamaño"}
	]
}


func guardar_puntaje(nombre: String, puntos: int) -> void:
	var lista = cargar_puntajes()
	lista.append({"nombre": nombre, "puntos": puntos})
	lista.sort_custom(func(a, b): return a["puntos"] > b["puntos"]) # Ordenar de mayor a menor (RF-10)
	
	var archivo = FileAccess.open(RUTA_PUNTAJES, FileAccess.WRITE)
	if archivo:
		archivo.store_string(JSON.stringify(lista))
		archivo.close()


func cargar_puntajes() -> Array:
	if not FileAccess.file_exists(RUTA_PUNTAJES):
		return []
	var archivo = FileAccess.open(RUTA_PUNTAJES, FileAccess.READ)
	var texto = archivo.get_as_text()
	archivo.close()
	var json = JSON.new()
	if json.parse(texto) == OK:
		return json.get_data()
	return []
