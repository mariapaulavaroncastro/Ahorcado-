extends Node

var banco_palabras = {
	"Países": ["COLOMBIA", "ARGENTINA", "JAPON", "FRANCIA", "CANADA"],
	"Animales": ["PERRO", "TIGRE", "ELEFANTE", "DELFIN", "JIRAFA"],
	"Tecnología": ["CELULAR", "COMPUTADOR", "TECLADO", "INTERNET", "ROBOT"]
}

var categoria_actual = "Países"
var nivel_actual = "Fácil"

var palabra_secreta = ""
var letras_adivinadas = []
var fallos = 0
var max_fallos = 6
var puntos = 0
var record_puntos = 0

@onready var visual = $GestorVisual

func _ready():
	randomize()
	visual.aplicar_estilos_base() 
	
	conectar_teclado()
	conectar_botones_superiores()
	conectar_menus_personalizados()
	
	nuevo_juego()

func nuevo_juego():
	var lista_palabras = banco_palabras[categoria_actual]
	palabra_secreta = lista_palabras[randi() % lista_palabras.size()]
	letras_adivinadas.clear()
	fallos = 0
	
	visual.crear_guiones(palabra_secreta.length())
	visual.reiniciar_teclado()
	visual.actualizar_interfaz("Pista: " + categoria_actual, fallos, max_fallos, puntos)

func conectar_teclado():
	for boton in $ContenedorPrincipal/Teclado.get_children():
		if boton is Button:
			if not boton.pressed.is_connected(_on_letra_presionada):
				boton.pressed.connect(_on_letra_presionada.bind(boton))

func _on_letra_presionada(boton: Button):
	boton.disabled = true
	var letra = boton.text.to_upper()
	
	if letra in palabra_secreta:
		puntos += 10
		if puntos > record_puntos:
			record_puntos = puntos
			visual.actualizar_texto_record(record_puntos)
			
		for i in range(palabra_secreta.length()):
			if palabra_secreta[i] == letra:
				letras_adivinadas.append(letra)
				visual.revelar_letra(i, letra)
		
		if letras_adivinadas.size() == palabra_secreta.length():
			visual.actualizar_interfaz("¡GANASTE!", fallos, max_fallos, puntos)
			visual.deshabilitar_teclado()
	else:
		fallos += 1
		if fallos >= max_fallos:
			visual.actualizar_interfaz("¡PERDISTE! Era: " + palabra_secreta, fallos, max_fallos, puntos)
			visual.deshabilitar_teclado()
			puntos = 0 # Reiniciamos puntos si pierde
		else:
			visual.actualizar_interfaz("Pista: " + categoria_actual, fallos, max_fallos, puntos)

#conexion botones
func conectar_botones_superiores():
	$ContenedorPrincipal/BarraSuperior/BotonCerrar.pressed.connect(func(): _abrir_panel(visual.panel_salida))
	$ContenedorPrincipal/BarraSuperior/BotonMenu.pressed.connect(func(): _abrir_panel(visual.panel_menu))
	$ContenedorPrincipal/BarraSuperior/BotonAyuda.pressed.connect(func(): _abrir_panel(visual.panel_ayuda))

#conexion menu
func conectar_menus_personalizados():
	# Navegación del Menú Principal
	visual.btn_cerrar_menu.pressed.connect(_cerrar_todas_las_ventanas)
	visual.btn_reiniciar.pressed.connect(_on_reiniciar_presionado)
	visual.btn_abrir_categorias.pressed.connect(func(): _abrir_panel(visual.panel_categorias))
	visual.btn_abrir_niveles.pressed.connect(func(): _abrir_panel(visual.panel_niveles))
	visual.btn_abrir_records.pressed.connect(func(): _abrir_panel(visual.panel_records))
	
	#Ayuda y Salida
	visual.btn_cerrar_ayuda.pressed.connect(_cerrar_todas_las_ventanas)
	visual.btn_cancelar_salida.pressed.connect(_cerrar_todas_las_ventanas)
	visual.btn_confirmar_salida.pressed.connect(func(): get_tree().quit())
	
	#Botones de volver en submenús
	visual.btn_cerrar_cat.pressed.connect(func(): _abrir_panel(visual.panel_menu))
	visual.btn_cerrar_niv.pressed.connect(func(): _abrir_panel(visual.panel_menu))
	visual.btn_cerrar_rec.pressed.connect(func(): _abrir_panel(visual.panel_menu))
	
	#Acciones de Categorías
	visual.btn_cat_paises.pressed.connect(func(): _cambiar_categoria("Países"))
	visual.btn_cat_animales.pressed.connect(func(): _cambiar_categoria("Animales"))
	visual.btn_cat_tecnologia.pressed.connect(func(): _cambiar_categoria("Tecnología"))
	
	#Acciones de Niveles
	visual.btn_niv_facil.pressed.connect(func(): _cambiar_nivel("Fácil", 6))
	visual.btn_niv_medio.pressed.connect(func(): _cambiar_nivel("Medio", 4))
	visual.btn_niv_dificil.pressed.connect(func(): _cambiar_nivel("Difícil", 3))

#logica de paneles
func _abrir_panel(panel_a_mostrar: PanelContainer):
	_cerrar_todas_las_ventanas()
	visual.fondo_oscuro.visible = true
	panel_a_mostrar.visible = true

func _cerrar_todas_las_ventanas():
	visual.fondo_oscuro.visible = false
	visual.panel_menu.visible = false
	visual.panel_ayuda.visible = false
	visual.panel_salida.visible = false
	visual.panel_categorias.visible = false
	visual.panel_niveles.visible = false
	visual.panel_records.visible = false

func _on_reiniciar_presionado():
	_cerrar_todas_las_ventanas()
	nuevo_juego()

func _cambiar_categoria(nueva_cat: String):
	categoria_actual = nueva_cat
	_cerrar_todas_las_ventanas()
	nuevo_juego()

func _cambiar_nivel(nombre_nivel: String, nuevos_fallos: int):
	nivel_actual = nombre_nivel
	max_fallos = nuevos_fallos
	visual.actualizar_texto_menu_nivel(nombre_nivel)
	_cerrar_todas_las_ventanas()
	nuevo_juego()
