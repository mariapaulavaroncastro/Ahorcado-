extends Node

const COLOR_AZUL = Color("0f2b78")
const COLOR_NEGRO = Color.BLACK
const COLOR_GRIS_TECLADO = Color("c2c7d0")
const COLOR_BLANCO = Color.WHITE
const COLOR_FONDO_OSCURO = Color(0, 0, 0, 0.6)

# Carga la fuente desde la carpeta assets
var fuente_personalizada = preload("res://assets/BalsamiqSans-Regular.ttf")

# referencias
@onready var teclado = $"../ContenedorPrincipal/Teclado"
@onready var contenedor_palabra = $"../ContenedorPrincipal/ContenedorPalabra"
@onready var label_pista = $"../ContenedorPrincipal/LabelPista"
@onready var label_fallos = $"../ContenedorPrincipal/BarraEstado/LabelFallos"
@onready var label_puntos = $"../ContenedorPrincipal/BarraEstado/LabelPuntos"
@onready var sprite = $"../ContenedorPrincipal/EspacioDibujo/AhorcadoSprite"

@onready var titulo = $"../ContenedorPrincipal/BarraSuperior/Titulo"
@onready var boton_menu = $"../ContenedorPrincipal/BarraSuperior/BotonMenu"
@onready var boton_ayuda = $"../ContenedorPrincipal/BarraSuperior/BotonAyuda"
@onready var boton_cerrar = $"../ContenedorPrincipal/BarraSuperior/BotonCerrar"

# menu
var capa_menus: CanvasLayer
var fondo_oscuro: ColorRect
var panel_menu: PanelContainer
var panel_ayuda: PanelContainer
var panel_salida: PanelContainer
var panel_categorias: PanelContainer
var panel_niveles: PanelContainer
var panel_records: PanelContainer

#botones
var btn_abrir_categorias: Button
var btn_abrir_niveles: Button
var btn_abrir_records: Button
var btn_reiniciar: Button
var btn_cerrar_menu: Button

var btn_cat_paises: Button
var btn_cat_animales: Button
var btn_cat_tecnologia: Button
var btn_cerrar_cat: Button

var btn_niv_facil: Button
var btn_niv_medio: Button
var btn_niv_dificil: Button
var btn_cerrar_niv: Button

var label_texto_record: Label
var btn_cerrar_rec: Button

var btn_cerrar_ayuda: Button
var btn_confirmar_salida: Button
var btn_cancelar_salida: Button

func aplicar_estilos_base():
	_configurar_textos()
	_configurar_barra_superior()
	_configurar_teclado()
	_crear_sistema_menus()

func _configurar_textos():
	#fuente
	label_pista.add_theme_font_override("font", fuente_personalizada)
	titulo.add_theme_font_override("font", fuente_personalizada)
	label_fallos.add_theme_font_override("font", fuente_personalizada)
	label_puntos.add_theme_font_override("font", fuente_personalizada)
	
	#tamaños
	titulo.add_theme_font_size_override("font_size", 42) 
	label_pista.add_theme_font_size_override("font_size", 36) 
	label_fallos.add_theme_font_size_override("font_size", 32) 
	label_puntos.add_theme_font_size_override("font_size", 32) 
	
	#colores
	label_pista.add_theme_color_override("font_color", COLOR_AZUL)
	titulo.add_theme_color_override("font_color", COLOR_NEGRO)
	label_fallos.add_theme_color_override("font_color", COLOR_NEGRO)
	label_puntos.add_theme_color_override("font_color", COLOR_NEGRO)
	
	
	titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	titulo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	
	var barra_estado = label_fallos.get_parent()
	if barra_estado is HBoxContainer:
		barra_estado.alignment = BoxContainer.ALIGNMENT_CENTER
		barra_estado.add_theme_constant_override("separation", 35) # Un poco más juntos
		label_fallos.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		label_puntos.size_flags_horizontal = Control.SIZE_SHRINK_CENTER

func _configurar_barra_superior():
	var estilo_circulo = _crear_estilo_circular(COLOR_BLANCO)
	var estilo_vacio = StyleBoxEmpty.new()
	var botones_superiores = [boton_menu, boton_ayuda, boton_cerrar]
	
	boton_menu.text = "≡"
	boton_ayuda.text = "?"
	boton_cerrar.text = "X"
	
	for btn in botones_superiores:
		btn.add_theme_font_override("font", fuente_personalizada)
		btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		
		btn.custom_minimum_size = Vector2(65, 65) # Antes 80x80
		btn.add_theme_font_size_override("font_size", 40) # Antes 48
		btn.add_theme_color_override("font_color", COLOR_NEGRO)
		
		btn.add_theme_stylebox_override("normal", estilo_circulo)
		btn.add_theme_stylebox_override("hover", estilo_circulo)
		btn.add_theme_stylebox_override("pressed", estilo_circulo)
		btn.add_theme_stylebox_override("focus", estilo_vacio)

func _configurar_teclado():
	teclado.add_theme_constant_override("h_separation", 10)
	teclado.add_theme_constant_override("v_separation", 12)
	teclado.columns = 7
	teclado.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	
	var estilo_circulo_normal = _crear_estilo_circular(COLOR_BLANCO)
	var estilo_circulo_presionado = _crear_estilo_circular(COLOR_GRIS_TECLADO)
	var estilo_vacio = StyleBoxEmpty.new()

	for boton in teclado.get_children():
		if boton is Button:
			boton.add_theme_font_override("font", fuente_personalizada)
			
			#teclado
			boton.custom_minimum_size = Vector2(75, 75) # Antes 90x90
			boton.add_theme_font_size_override("font_size", 36) # Antes 42
			
			boton.add_theme_color_override("font_color", COLOR_NEGRO)
			boton.add_theme_color_override("font_disabled_color", COLOR_AZUL)
			boton.add_theme_stylebox_override("normal", estilo_circulo_normal)
			boton.add_theme_stylebox_override("pressed", estilo_circulo_presionado)
			boton.add_theme_stylebox_override("disabled", estilo_circulo_presionado)
			boton.add_theme_stylebox_override("focus", estilo_vacio)

func _crear_estilo_circular(color_fondo: Color) -> StyleBoxFlat:
	var estilo = StyleBoxFlat.new()
	estilo.bg_color = color_fondo
	estilo.border_color = COLOR_NEGRO
	estilo.border_width_left = 2
	estilo.border_width_top = 2
	estilo.border_width_right = 2
	estilo.border_width_bottom = 2
	estilo.corner_radius_top_left = 50
	estilo.corner_radius_top_right = 50
	estilo.corner_radius_bottom_left = 50
	estilo.corner_radius_bottom_right = 50
	return estilo
	
#ventanas
func _crear_sistema_menus():
	capa_menus = CanvasLayer.new()
	capa_menus.layer = 10
	add_child(capa_menus)
	
	fondo_oscuro = ColorRect.new()
	fondo_oscuro.color = COLOR_FONDO_OSCURO
	fondo_oscuro.set_anchors_preset(Control.PRESET_FULL_RECT)
	fondo_oscuro.visible = false
	capa_menus.add_child(fondo_oscuro)
	
	var estilo_panel = _crear_estilo_panel_menu()
	
	# menú
	panel_menu = _crear_panel_base(estilo_panel)
	var vbox_menu = _crear_contenedor_base(panel_menu)
	btn_abrir_categorias = _agregar_boton_menu(vbox_menu, "Categorías")
	btn_abrir_niveles = _agregar_boton_menu(vbox_menu, "Nivel: Fácil")
	btn_abrir_records = _agregar_boton_menu(vbox_menu, "Récords")
	btn_reiniciar = _agregar_boton_menu(vbox_menu, "Volver al Inicio")
	btn_cerrar_menu = _agregar_boton_menu(vbox_menu, "X Cerrar")
	
	#categorias
	panel_categorias = _crear_panel_base(estilo_panel)
	var vbox_cat = _crear_contenedor_base(panel_categorias)
	_agregar_titulo_menu(vbox_cat, "CATEGORÍAS")
	btn_cat_paises = _agregar_boton_menu(vbox_cat, "Países")
	btn_cat_animales = _agregar_boton_menu(vbox_cat, "Animales")
	btn_cat_tecnologia = _agregar_boton_menu(vbox_cat, "Tecnología")
	btn_cerrar_cat = _agregar_boton_menu(vbox_cat, "Volver")

	#niveles
	panel_niveles = _crear_panel_base(estilo_panel)
	var vbox_niv = _crear_contenedor_base(panel_niveles)
	_agregar_titulo_menu(vbox_niv, "DIFICULTAD")
	btn_niv_facil = _agregar_boton_menu(vbox_niv, "Fácil (6 Fallos)")
	btn_niv_medio = _agregar_boton_menu(vbox_niv, "Medio (4 Fallos)")
	btn_niv_dificil = _agregar_boton_menu(vbox_niv, "Difícil (3 Fallos)")
	btn_cerrar_niv = _agregar_boton_menu(vbox_niv, "Volver")

	#records
	panel_records = _crear_panel_base(estilo_panel)
	var vbox_rec = _crear_contenedor_base(panel_records)
	_agregar_titulo_menu(vbox_rec, "RÉCORD MÁXIMO")
	label_texto_record = Label.new()
	label_texto_record.text = "Puntos: 0"
	label_texto_record.add_theme_font_override("font", fuente_personalizada)
	label_texto_record.add_theme_font_size_override("font_size", 34)
	label_texto_record.add_theme_color_override("font_color", COLOR_NEGRO)
	vbox_rec.add_child(label_texto_record)
	btn_cerrar_rec = _agregar_boton_menu(vbox_rec, "Volver")
	
	#ayuda
	panel_ayuda = _crear_panel_base(estilo_panel)
	var vbox_ayuda = _crear_contenedor_base(panel_ayuda)
	_agregar_titulo_menu(vbox_ayuda, "CÓMO JUGAR")
	var texto_ayuda = Label.new()
	texto_ayuda.text = "Adivina la palabra secreta\nletra por letra.\n\nEvita que el ahorcado\nse complete."
	texto_ayuda.add_theme_font_override("font", fuente_personalizada)
	texto_ayuda.add_theme_font_size_override("font_size", 30)
	texto_ayuda.add_theme_color_override("font_color", COLOR_NEGRO)
	vbox_ayuda.add_child(texto_ayuda)
	btn_cerrar_ayuda = _agregar_boton_menu(vbox_ayuda, "Entendido")
	
	# salida
	panel_salida = _crear_panel_base(estilo_panel)
	var vbox_salida = _crear_contenedor_base(panel_salida)
	_agregar_titulo_menu(vbox_salida, "SALIR")
	var texto_salida = Label.new()
	texto_salida.text = "¿Estás seguro de que\ndeseas salir?"
	texto_salida.add_theme_font_override("font", fuente_personalizada)
	texto_salida.add_theme_font_size_override("font_size", 30)
	texto_salida.add_theme_color_override("font_color", COLOR_NEGRO)
	vbox_salida.add_child(texto_salida)
	
	var hbox_botones_salida = HBoxContainer.new()
	hbox_botones_salida.alignment = BoxContainer.ALIGNMENT_CENTER
	hbox_botones_salida.add_theme_constant_override("separation", 20)
	btn_cancelar_salida = _agregar_boton_menu(hbox_botones_salida, "No")
	btn_confirmar_salida = _agregar_boton_menu(hbox_botones_salida, "Sí")
	vbox_salida.add_child(hbox_botones_salida)

func _crear_panel_base(estilo: StyleBoxFlat) -> PanelContainer:
	var panel = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", estilo)
	panel.set_anchors_preset(Control.PRESET_CENTER_LEFT)
	panel.offset_left = 20
	panel.visible = false
	capa_menus.add_child(panel)
	
	var cuadricula = CuadriculaFondo.new()
	panel.add_child(cuadricula)
	return panel

func _crear_contenedor_base(padre: PanelContainer) -> VBoxContainer:
	var margin = MarginContainer.new()
	margin.add_theme_constant_override("margin_top", 40)
	margin.add_theme_constant_override("margin_bottom", 40)
	margin.add_theme_constant_override("margin_left", 40)
	margin.add_theme_constant_override("margin_right", 40)
	padre.add_child(margin)
	
	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 25)
	margin.add_child(vbox)
	return vbox

func _agregar_titulo_menu(padre: Control, texto: String):
	var lbl = Label.new()
	lbl.text = texto
	lbl.add_theme_font_override("font", fuente_personalizada)
	lbl.add_theme_font_size_override("font_size", 42)
	lbl.add_theme_color_override("font_color", COLOR_NEGRO)
	padre.add_child(lbl)

func _crear_estilo_panel_menu() -> StyleBoxFlat:
	var estilo = StyleBoxFlat.new()
	estilo.bg_color = COLOR_BLANCO
	estilo.border_color = COLOR_NEGRO
	estilo.border_width_left = 3
	estilo.border_width_top = 3
	estilo.border_width_right = 3
	estilo.border_width_bottom = 3
	estilo.corner_radius_top_left = 15
	estilo.corner_radius_top_right = 15
	estilo.corner_radius_bottom_left = 15
	estilo.corner_radius_bottom_right = 15
	estilo.shadow_color = Color(0, 0, 0, 0.3)
	estilo.shadow_size = 10
	return estilo

func _agregar_boton_menu(padre: Control, texto: String) -> Button:
	var btn = Button.new()
	btn.text = texto
	btn.add_theme_font_override("font", fuente_personalizada)
	btn.add_theme_font_size_override("font_size", 34)
	btn.add_theme_color_override("font_color", COLOR_NEGRO)
	btn.add_theme_color_override("font_hover_color", COLOR_AZUL)
	btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	
	var estilo_vacio = StyleBoxEmpty.new()
	estilo_vacio.content_margin_left = 12
	estilo_vacio.content_margin_right = 12
	estilo_vacio.content_margin_top = 10
	estilo_vacio.content_margin_bottom = 10
	
	var estilo_hover = StyleBoxFlat.new()
	estilo_hover.bg_color = Color(0, 0, 0, 0.08)
	estilo_hover.corner_radius_top_left = 8
	estilo_hover.corner_radius_top_right = 8
	estilo_hover.corner_radius_bottom_left = 8
	estilo_hover.corner_radius_bottom_right = 8
	estilo_hover.content_margin_left = 12
	estilo_hover.content_margin_right = 12
	estilo_hover.content_margin_top = 10
	estilo_hover.content_margin_bottom = 10
	
	btn.add_theme_stylebox_override("normal", estilo_vacio)
	btn.add_theme_stylebox_override("hover", estilo_hover)
	btn.add_theme_stylebox_override("pressed", estilo_hover)
	btn.add_theme_stylebox_override("focus", estilo_vacio)
	
	padre.add_child(btn)
	return btn

#funciones juego
func actualizar_texto_menu_nivel(texto: String):
	btn_abrir_niveles.text = "Nivel: " + texto

func actualizar_texto_record(record: int):
	label_texto_record.text = "Puntos: " + str(record)

func crear_guiones(cantidad: int):
	for child in contenedor_palabra.get_children():
		child.queue_free()
	for i in range(cantidad):
		var contenedor_letra = VBoxContainer.new()
		contenedor_letra.alignment = BoxContainer.ALIGNMENT_CENTER
		var label_letra = Label.new()
		label_letra.text = " "
		label_letra.add_theme_font_override("font", fuente_personalizada)
		label_letra.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		
		label_letra.add_theme_font_size_override("font_size", 55) # Antes 75
		label_letra.add_theme_color_override("font_color", COLOR_AZUL)
		
		var linea = ColorRect.new()
		linea.custom_minimum_size = Vector2(45, 5) # Antes 60, 6
		linea.color = COLOR_AZUL
		
		contenedor_letra.add_child(label_letra)
		contenedor_letra.add_child(linea)
		contenedor_palabra.add_child(contenedor_letra)

func revelar_letra(indice: int, letra: String):
	var vbox = contenedor_palabra.get_child(indice)
	vbox.get_child(0).text = letra

func actualizar_interfaz(pista: String, fallos_act: int, max_fallos: int, puntos_act: int):
	label_pista.text = pista
	label_fallos.text = "Fallos: " + str(fallos_act) + "/" + str(max_fallos)
	label_puntos.text = "Puntos: " + str(puntos_act)
	
	var frame_calculado = (fallos_act * 6) / max_fallos 
	sprite.frame = min(frame_calculado, 6)

func reiniciar_teclado():
	for boton in teclado.get_children():
		if boton is Button:
			boton.disabled = false
			
func deshabilitar_teclado():
	for boton in teclado.get_children():
		if boton is Button:
			boton.disabled = true


class CuadriculaFondo extends Control:
	func _ready():
		set_anchors_preset(Control.PRESET_FULL_RECT)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw():
		var w = size.x
		var h = size.y
		var paso = 25
		var color_linea = Color(0.85, 0.85, 0.9, 1.0)
		for x in range(0, int(w), paso): draw_line(Vector2(x, 0), Vector2(x, h), color_linea, 1.0)
		for y in range(0, int(h), paso): draw_line(Vector2(0, y), Vector2(w, y), color_linea, 1.0)
	func _notification(what):
		if what == NOTIFICATION_RESIZED: queue_redraw()
